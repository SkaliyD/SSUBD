create function union_repair_details_services__truncate_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
			UPDATE repair_details
			SET ids_service = ARRAY[]::INTEGER[];
			
			RETURN NULL;
		END;
$$;
