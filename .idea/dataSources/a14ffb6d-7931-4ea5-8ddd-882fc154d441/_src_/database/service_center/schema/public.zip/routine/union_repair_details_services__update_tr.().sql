create function union_repair_details_services__update_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
			UPDATE repair_details
			SET ids_service = ids_service - OLD.id_service
			WHERE id_repair_detail = OLD.id_repair_detail;

			UPDATE repair_details
			SET ids_service = ids_service + NEW.id_service 
			WHERE id_repair_detail = NEW.id_repair_detail;

			RETURN NEW;
		END;
$$;
