create function union_repair_details_components__truncate_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
			UPDATE repair_details
			SET ids_component = ARRAY[]::INTEGER[];
			
			RETURN NULL;
		END;
$$;
