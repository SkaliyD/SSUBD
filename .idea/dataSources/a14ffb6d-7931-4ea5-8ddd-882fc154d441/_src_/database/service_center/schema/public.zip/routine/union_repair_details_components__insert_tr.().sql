create function union_repair_details_components__insert_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
			UPDATE repair_details
			SET ids_component = ids_component + NEW.id_component 
			WHERE id_repair_detail = NEW.id_repair_detail;

			RETURN NEW;
		END;
$$;
